package com.lohan.crackme0a;

public final class R
{
  public static final class attr
  {
  }

  public static final class drawable
  {
    public static final int icon = 2130837504;
  }

  public static final class id
  {
    public static final int RelativeLayout1 = 2131034112;
    public static final int TextView01 = 2131034113;
    public static final int btn_validate = 2131034116;
    public static final int edt_code = 2131034115;
    public static final int tv_reg_text = 2131034114;
  }

  public static final class layout
  {
    public static final int main = 2130903040;
  }

  public static final class string
  {
    public static final int app_name = 2130968576;
    public static final int btn_validate = 2130968578;
    public static final int txt_enter_code = 2130968577;
  }
}

/* Location:           /home/softsec/Desktop/1/crackme2-dex/classes_dex2jar.jar
 * Qualified Name:     com.lohan.crackme0a.R
 * JD-Core Version:    0.6.2
 */