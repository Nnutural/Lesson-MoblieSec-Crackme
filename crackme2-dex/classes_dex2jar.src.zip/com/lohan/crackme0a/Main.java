package com.lohan.crackme0a;

import android.app.Activity;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.text.Editable;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import java.math.BigInteger;
import java.security.MessageDigest;

public class Main extends Activity
  implements View.OnClickListener
{
  private String generateIDHash()
    throws Exception
  {
    String str = getMobileID();
    MessageDigest localMessageDigest = MessageDigest.getInstance("MD5");
    localMessageDigest.update(str.getBytes(), 0, str.length());
    byte[] arrayOfByte1 = localMessageDigest.digest();
    byte[] arrayOfByte2 = new byte[arrayOfByte1.length];
    int i = 0;
    int j = 0;
    if (i >= arrayOfByte1.length)
      return new BigInteger(1, arrayOfByte2).toString(16).substring(0, 15);
    if (i >= -1 + arrayOfByte1.length);
    for (int k = 0; ; k = i + 1)
    {
      arrayOfByte2[j] = ((byte)(arrayOfByte1[i] ^ arrayOfByte1[k]));
      i += 2;
      j++;
      break;
    }
  }

  private String getMobileID()
    throws Exception
  {
    return ((TelephonyManager)getSystemService("phone")).getDeviceId();
  }

  private int validateSerial(String paramString)
  {
    try
    {
      boolean bool = generateIDHash().equals(paramString);
      if (bool)
      {
        i = 1;
        return i;
      }
    }
    catch (Exception localException)
    {
      while (true)
      {
        localException.printStackTrace();
        int i = 0;
      }
    }
  }

  public void onClick(View paramView)
  {
    switch (paramView.getId())
    {
    default:
    case 2131034116:
    }
    while (true)
    {
      return;
      EditText localEditText = (EditText)findViewById(2131034115);
      if (validateSerial(localEditText.getText().toString()) == 0)
      {
        Toast.makeText(this, "Invalid code.\nTry again.", 1).show();
      }
      else
      {
        Toast.makeText(this, "Code is valid!", 1).show();
        localEditText.setVisibility(4);
        ((Button)findViewById(2131034116)).setVisibility(4);
        ((TextView)findViewById(2131034114)).setText("Code Accepted :D");
      }
    }
  }

  public void onCreate(Bundle paramBundle)
  {
    super.onCreate(paramBundle);
    setContentView(2130903040);
    ((Button)findViewById(2131034116)).setOnClickListener(this);
  }
}

/* Location:           /home/softsec/Desktop/1/crackme2-dex/classes_dex2jar.jar
 * Qualified Name:     com.lohan.crackme0a.Main
 * JD-Core Version:    0.6.2
 */